"""
A tensor is just a n-dimensional array
"""
from numpy import ndarray as Tensor
